# Práctica 1 - PAUTLEN 1311
## Clase 1311
## Grupo 2

### Parte prodedural - Análisis morfológico 