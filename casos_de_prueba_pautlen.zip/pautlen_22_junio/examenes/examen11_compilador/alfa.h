#ifndef _ALFA_H
#define _ALFA_H

#define MAX_LONG_ID 100
#define MAX_TAMANIO_VECTOR 64


/*Aquí van a ir otros defines*/

typedef struct {
  char lexema[MAX_LONG_ID+1]; /*Para los identificadores.*/
  int tipo; /*Para comprobación de tipos básicos*/
  int valor_entero; /*Para constantes enteras.*/
  int es_direccion; /*Para controlar lo que representa cada símbolo (una dirección de memoria o un valor constante).*/
  int etiqueta; /*Para la generación de código de sentencias condicionales e iterativas.*/
  int categoria;
}tipo_atributos;


#endif
