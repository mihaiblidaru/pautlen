#include "alfa.y"

int main(int argc, char *argv[]){
    int valor_yylex=0;

    if(argc < 2){
      printf("Por favor, ejecutalo de la siguiente manera: ./pruebaSintactico <entrada> <salida>\n");
      return -1;
    }

    yyparse();


    return 0;
}
