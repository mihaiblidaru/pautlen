/***********************************************
* Archivo tabla_simbolo.c                      *
* Autores: Carlos Gonzalez Garcia              *
*          Sergio Romero Tapiador              *
* Fecha: 20/10/2017                            *
***********************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tablaHash.h"

#define MAX_LINEA 1000
#define SIZE_BUFFER 300
#define SIZE_TABLE 200

int main (int argc, char*argv[]){

  FILE * fp = NULL,*file_out= NULL;
  char *buffer, *lexema, *simbolo=NULL;
  TABLA_HASH* th_global = NULL;
  TABLA_HASH* th_local = NULL;
  int param;
  STATUS stat;
  INFO_SIMBOLO* is;

  printf("\n\e[36m[Compilador]:\e[30m Se ha iniciado la ejecucion...\n");

  if (argc < 2){
    printf("\e[36m[Compilador]:\e[30m Por favor, ejecutelo de la siguiente manera: ./practica2 <fichero_entrada> <fichero_salida>\n");
    exit(-1);
  }

  fp = fopen(argv[1],"r");
  if (fp == NULL){
    exit(-1);
  }
  file_out=fopen (argv[2],"w");
  if (file_out == NULL){
    exit(-1);
  }

  buffer = (char*)malloc(sizeof(char)*SIZE_BUFFER);

  th_global = crear_tabla(SIZE_TABLE); /*¿Que tamaño tiene que tener?*/

  while (fgets(buffer, MAX_LINEA, fp) != NULL){
  	lexema = strtok(buffer," ");
  	simbolo = strtok(NULL,"\n");
    if (simbolo == NULL) { /*CASO DE BUSQUEDA*/
  		lexema[strlen(lexema)-1] = '\0';
  		is = buscar_simbolo(th_global, lexema);
  		if (is == NULL){
        fprintf(file_out,"%s -1\n",lexema);
  			printf("\n\e[36m[Compilador]:\e[30m El elemento \e[91m<%s>\e[30m no se ha encontrado en la tabla.",lexema);
  		} else {
        fprintf(file_out,"%s %d\n",lexema,is->adicional1);
  			printf("\n\e[36m[Compilador]:\e[30m El elemento \e[91m <%s>\e[30m  se ha encontrado en la tabla.",lexema);
  		}
    }
    else{ /*CASO DE INSERCION*/
    	param = atoi(simbolo);
   	 	if(param <0){ /*SI EL PARAMETRO ES NEGATIVO, ABRIMOS UN NUEVO AMBITO PARA LA FUNCION*/
        stat = insertar_simbolo(th_global, lexema, VARIABLE, ENTERO, ESCALAR, param,  0);
        th_local = crear_tabla(SIZE_TABLE);
        stat = insertar_simbolo(th_local, lexema, VARIABLE, ENTERO, ESCALAR, param,  0);
        fprintf(file_out,"%s\n",lexema);

        while (fgets(buffer,MAX_LINEA,fp) != NULL && strcmp(lexema = strtok(buffer," "),"cierre") != 0  && ((int)*(simbolo = strtok(NULL,"\n")) != -999)){
          if (simbolo == NULL) { /*CASO DE BUSQUEDA*/
        		lexema[strlen(lexema)-1] = '\0';
        		is = buscar_simbolo(th_local, lexema);
        		if (is == NULL){
        			is = buscar_simbolo(th_global, lexema);
        			if (is == NULL){
        				fprintf(file_out,"%s -1\n",lexema);
        				printf("\n\e[36m[Compilador]:\e[30m El elemento \e[91m<%s>\e[30m no se ha encontrado en la tabla.",lexema);
        			}
					else {
	             		fprintf(file_out,"%s %d\n",lexema,is->adicional1);
	        			printf("\n\e[36m[Compilador]:\e[30m El elemento \e[91m <%s>\e[30m  se ha encontrado en la tabla.",lexema);
        			}

        		} else {
             		fprintf(file_out,"%s %d\n",lexema,is->adicional1);
        			printf("\n\e[36m[Compilador]:\e[30m El elemento \e[91m <%s>\e[30m  se ha encontrado en la tabla.",lexema);
        		}
          }
          else{ /*CASO DE INSERCION*/
            	param =  atoi(simbolo);
           	 	if(param <0){ /*No puede haber un ambito local dentro de un ambito local*/
                printf("ERROR\n");
            	}
        	    stat = insertar_simbolo(th_local, lexema, VARIABLE, ENTERO, ESCALAR, param,  0);
        	    if (stat == ERR){
                fprintf(file_out,"-1 %s\n",lexema);
        	    	printf("\n\e[36m[Compilador]:\e[30m El simbolo <%d> no se ha insertado correctamente LOCAL.", param);
        	    } else {
                fprintf(file_out,"%s\n",lexema);
        	    	printf("\n\e[36m[Compilador]:\e[30m El simbolo <%d> se ha insertado correctamente LOCAL.", param);
        	    }
      	   }
        }/*Cierre del while*/
        if(strcmp("cierre", lexema) == 0){
          fprintf(file_out,"cierre\n");
          printf("\n\e[36m[Compilador]:\e[30m Se ha cerrado el ambito local con exito.");
          liberar_tabla(th_local);
        }

    	}
          else{
            stat = insertar_simbolo(th_global, lexema, VARIABLE, ENTERO, ESCALAR, param,  0);
      	    if (stat == ERR){
              fprintf(file_out,"-1 %s\n",lexema);
      	    	printf("\n\e[36m[Compilador]:\e[30m El simbolo <%d> no se ha insertado correctamente.", param);
      	    } else {
              fprintf(file_out,"%s\n",lexema);
      	    	printf("\n\e[36m[Compilador]:\e[30m El simbolo <%d> se ha insertado correctamente.", param);
      	    }
          }

	   }
  }

  	printf("\n\n\e[36m[Compilador]:\e[30m Se ha terminado la ejecucion...\n\n");
    free(buffer);
    liberar_tabla(th_global);
    fclose(fp);
    fclose(file_out);
    exit(0);
}
