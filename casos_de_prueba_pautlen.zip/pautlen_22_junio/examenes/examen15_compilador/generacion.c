/*********************************************************
* Practica 0:Conceptos de Generación de Código.          *
*            El lenguaje NASM.                           *
*				                                                 *
* Realizado por :                       		             *
*		             Carlos González García           			 *
*		             Sergio Romero Tapiador       		       *
* Fecha de realizacion: 07/10/2017       		             *
*********************************************************/
#include <stdio.h>
#include <string.h>
#include "generacion.h"

void escribir_cabecera_compatibilidad(FILE* fpasm){
  /*Esta la dejamos vacía*/
}

void escribir_subseccion_data(FILE* fpasm){
  if (fpasm == NULL){
    return;
  }
  fprintf(fpasm, "\nsegment .data\n\t_mensaje_1 db \"****Error de ejecucion: Indice fuera de rango\", 0\n\t_mensaje_2 db \"****Error de ejecucion: Division por cero\", 0\n");
}

void escribir_cabecera_bss(FILE* fpasm){
  if (fpasm == NULL){
    return;
  }
  fprintf(fpasm, "segment .bss\n");
  fprintf(fpasm, "\t__esp resd 1\n");
}

void declarar_variable(FILE* fpasm, char * nombre,  int tipo,  int tamano){
  if (fpasm == NULL || nombre == NULL || tamano < 0){
    return;
  }
  if (tipo == ESCALAR){
      fprintf(fpasm, "\t_%s resd 1\n", nombre);
  } else if (tipo == VECTOR){
      fprintf(fpasm, "\t_%s resd %d\n", nombre,  tamano);
  } else {
      fprintf(stdout, ";ERROR. La variable no es ni escalar ni vector");
      fprintf(fpasm, ";ERROR. La variable no es ni escalar ni vector");
      return;
  }
}

void escribir_segmento_codigo(FILE* fpasm){
  if (fpasm == NULL){
    return;
  }
  fprintf(fpasm,"segment .text\n\tglobal main\n\textern scan_int, print_int, scan_float,"
     "print_float\n\textern scan_boolean, print_boolean\n\textern print_endofline, print_blank, print_string\n\textern alfa_malloc, alfa_free, ld_float\n\t");
}

void escribir_inicio_main(FILE* fpasm){
  if(fpasm == NULL){
    return;
  }
  fprintf(fpasm, "\nmain:\n\tmov dword [__esp], esp\n");
}

void escribir_fin(FILE* fpasm){
  if (fpasm == NULL){
    return;
  }
  fprintf(fpasm,"\tmov dword esp, [__esp]\n\tret\n_error_1: push dword _mensaje_1\n\tcall print_string\n\tadd esp, 4\n\tcall print_endofline\n\tjmp near fin\n_error_2:\n\tpush dword"
    " _mensaje_2\n\tcall print_string\n\tadd esp, 4\n\tcall print_endofline\n\tjmp near fin\nfin:\n\tmov dword esp, [__esp]\n\tret");
}

void escribir_operando(FILE* fpasm, char* nombre, int es_var){
  if (fpasm == NULL || nombre == NULL){
    return;
  }
  if (es_var == 1){
    fprintf(fpasm,"\tpush dword [_%s]\n",nombre);
  } else {
    fprintf(fpasm,"\tpush dword _%s\n",nombre);
  }
}

void sumar(FILE* fpasm, int es_referencia_1, int es_referencia_2){
  if(fpasm == NULL){
    return;
  }

  fprintf(fpasm, "\tpop dword edx\n");
  fprintf(fpasm, "\tpop dword eax\n");

  if (es_referencia_1) fprintf(fpasm, "\tmov eax, dword [eax]\n");
  if (es_referencia_2) fprintf(fpasm, "\tmov edx, dword [edx]\n");

  fprintf(fpasm, "\tadd eax, edx\n");
  fprintf(fpasm,"\tpush dword eax\n");
}

void restar(FILE* fpasm, int es_referencia_1, int es_referencia_2){
  if(fpasm == NULL){
    return;
  }

    fprintf(fpasm, "\tpop dword edx\n");
    fprintf(fpasm, "\tpop dword eax\n");

    if (es_referencia_1) fprintf(fpasm, "\tmov eax, dword [eax]\n");
    if (es_referencia_2) fprintf(fpasm, "\tmov edx, dword [edx]\n");

    fprintf(fpasm, "\tsub eax, edx\n");
    fprintf(fpasm,"\tpush dword eax\n");
}

void multiplicar(FILE* fpasm, int es_referencia_1, int es_referencia_2){
  if(fpasm == NULL){
    return;
  }
  fprintf(fpasm, "\tpop dword eax\n");
  fprintf(fpasm, "\tpop dword ebx\n");

  if (es_referencia_1) fprintf(fpasm, "\tmov eax, dword [eax]\n");
  if (es_referencia_2) fprintf(fpasm, "\tmov ebx, dword [ebx]\n");

  fprintf(fpasm, "\tpush dword edx\n");
  fprintf(fpasm, "\timul ebx\n");
  fprintf(fpasm, "\tpop dword edx\n");
  fprintf(fpasm, "\tpush dword eax\n");
}

void dividir(FILE* fpasm, int es_referencia_1, int es_referencia_2){
  if(fpasm == NULL){
    return;
  }

  fprintf(fpasm, "\tpop dword ebx\n");
  fprintf(fpasm, "\tpop dword eax\n");

  if (es_referencia_1) fprintf(fpasm, "\tmov eax,  [eax]\n");

  fprintf(fpasm, "\tcdq\n");

  if (es_referencia_2) fprintf(fpasm, "\tmov ebx, dword [ebx]\n");
  fprintf(fpasm,"\tcmp ebx, 0\n");
  fprintf(fpasm,"\tje _error_2\n");

  fprintf(fpasm, "\tidiv ebx\n");
  fprintf(fpasm, "\tpush dword eax\n"); /*COCIENTE*/
}

void o(FILE* fpasm, int es_referencia_1, int es_referencia_2){
  if(fpasm == NULL){
    return;
  }

    fprintf(fpasm, "\tpop dword edx\n");
    fprintf(fpasm, "\tpop dword eax\n");

    if (es_referencia_1) fprintf(fpasm, "\tmov eax, dword [eax]\n");
    if (es_referencia_2) fprintf(fpasm, "\tmov edx, dword [edx]\n");

    fprintf(fpasm, "\tor eax, edx\n");
    fprintf(fpasm,"\tpush dword eax\n");
}

void y(FILE* fpasm, int es_referencia_1, int es_referencia_2){
  if(fpasm == NULL){
    return;
  }

    fprintf(fpasm, "\tpop dword edx\n");
    fprintf(fpasm, "\tpop dword eax\n");

    if (es_referencia_1) fprintf(fpasm, "\tmov eax, dword [eax]\n");
    if (es_referencia_2) fprintf(fpasm, "\tmov edx, dword [edx]\n");

    fprintf(fpasm, "\tand eax, edx\n");
    fprintf(fpasm,"\tpush dword eax\n");
}

void cambiar_signo(FILE* fpasm, int es_referencia){
  if (fpasm == NULL){
    return;
  }
  fprintf(fpasm, "\tpop dword eax\n");

  if (es_referencia == 1){
    fprintf(fpasm, "\tmov eax,[eax]\n");
  }
  fprintf(fpasm,"\tnot eax\n");
  fprintf(fpasm,"\tinc eax\n");
  fprintf(fpasm,"\tpush dword eax\n");
}

void no(FILE* fpasm, int es_referencia, int cuantos_no){
  if (fpasm == NULL){
    return;
  }
  fprintf(fpasm, "\tpop dword eax\n");
  if (es_referencia == 1){
    fprintf(fpasm, "\tmov eax,[eax]\n");
  }
  fprintf(fpasm,"\tor eax, eax\n");
  fprintf(fpasm,"\tjz near negar_falso%d\n",cuantos_no);
  fprintf(fpasm,"\tmov dword eax,0\n");
  fprintf(fpasm,"\tjmp near fin_negacion%d\n",cuantos_no);
  fprintf(fpasm,"\tnegar_falso%d: mov dword eax,1\n",cuantos_no);
  fprintf(fpasm, "\nfin_negacion%d: push dword eax\n", cuantos_no);

}

/* FUNCIONES DE ESCRITURA Y LECTURA */
void leer(FILE* fpasm, char* nombre, int tipo){
  if(fpasm == NULL || nombre == NULL ){
    return;
  }
  fprintf(fpasm,"\tpush dword _%s\n",nombre);
  if(tipo == INT){
    fprintf(fpasm, "\tcall scan_int\n" );
  }
  else{
    fprintf(fpasm, "\tcall scan_boolean\n" );
  }

  fprintf(fpasm, "\tadd esp, 4\n" );
}
void escribir(FILE* fpasm, int es_referencia, int tipo){
  if(fpasm == NULL){
    return;
  }
  if(es_referencia == 1){
    fprintf(fpasm, "\tpop dword eax\n\tmov dword eax, [eax]\n\tpush dword eax\n");
  }

  fprintf(fpasm, "\tcall print_%s\n", tipo == INT ? "int" : "boolean");

  if(es_referencia == 1){
    fprintf(fpasm,"\tadd esp, 4\n");
  }

  fprintf(fpasm, "\tcall print_endofline\n");

}
void comprobar_indices(FILE *fpasm, int es_referencia,int tamano){
  if(fpasm == NULL){
    return;
  }
  fprintf(fpasm,";Carga del valor del indice en eax\n\tpop dword eax\n");

  if(es_referencia == 1){
    fprintf(fpasm, "\tmov dword eax, [eax]\n");
  }
  fprintf(fpasm, ";Si el indice es menor que 0, error en tiempo de ejecución\n\tcmp eax, 0\n\tjl near _error_1\n" );
  fprintf(fpasm, ";Si el indice es mayor de lo permitido, error en tiempo de ejecución\n\tcmp eax, %d\n\tjg near _error_1\n", (tamano-1));

}
void indexar_vector(FILE *fpasm, char * lexema, int explist){
  if(fpasm == NULL){
    return;
  }
  fprintf(fpasm,";Cargar en edx la direccion de inicio del vector\n\tmov dword edx, _%s\n",lexema);
  fprintf(fpasm, ";Cargar en eax la dirección del elemento indexado\n\tlea eax, [edx +eax *4]\n" );
  if(explist == 1){
    fprintf(fpasm, ";Apilar la dirección del elemento indexado\n\tpush dword [eax]\n");;
  }else{
    fprintf(fpasm, ";Apilar la dirección del elemento indexado\n\tpush dword eax\n");
  }


}
void asignar_expresion_a_elemento_identificador(FILE *fpasm,char * nombre, int es_referencia){
  if(fpasm == NULL){
    return;
  }
  fprintf(fpasm,";Cargar en eax la parte derecha de la asignacion\n\tpop dword eax\n");

  if(es_referencia == 1){
    fprintf(fpasm, "\tmov dword eax, [eax]\n");
  }

  fprintf(fpasm, ";Hacer la asignacion efectiva\n\tmov dword [_%s],eax\n",nombre);
}
void asignar_expresion_a_elemento_identificador_funcion(FILE *fpasm, int es_referencia,int num_variable){
  if(fpasm == NULL){
    return;
  }
  fprintf(fpasm,";Cargar en eax la parte derecha de la asignacion\n\tpop dword eax\n");

  if(es_referencia == 1){
    fprintf(fpasm, "\tmov dword eax, [eax]\n");
  }

  fprintf(fpasm, ";Hacer la asignacion efectiva\n\tmov dword [ebp - 4* %d],eax\n",num_variable);
}
void asignar_expresion_a_vector(FILE *fpasm, int es_referencia){
  if(fpasm == NULL){
    return;
  }
  fprintf(fpasm,";Cargar en eax la parte derecha de la asignacion\n\tpop dword eax\n");

  if(es_referencia == 1){
    fprintf(fpasm, "\tmov dword eax, [eax]\n");
  }

  fprintf(fpasm, ";Cargar en edx la parte izquierda de la asignacion\n\tpop dword edx\n" );
  fprintf(fpasm, ";Hacer la asignacion efectiva\n\tmov dword [edx],eax\n");

}

void comparacion_igual(FILE* fpasm, int es_referencia_1, int es_referencia_2, int etiqueta){
  if(fpasm == NULL){
    return;
  }

  fprintf(fpasm,";Cargar la segunda expresion en edx\n\tpop dword edx\n");
  if(es_referencia_1 == INT){
    fprintf(fpasm, "\tmov dword edx, [edx]\n");
  }

  fprintf(fpasm,";Cargar la primera expresion en eax\n\tpop dword eax\n");
  if(es_referencia_2 == INT){
    fprintf(fpasm, "\tmov dword eax, [eax]\n");
  }

  fprintf(fpasm,";Comparar y apilar el resultado\n");
  fprintf(fpasm,"\tcmp eax, edx\n\tje near igual%d\n\tpush dword 0\n\tjmp near fin_igual%d\n", etiqueta, etiqueta);
  fprintf(fpasm,"igual%d:\n\tpush dword 1\n\tfin_igual%d:\n", etiqueta, etiqueta);
}

void comparacion_distinto(FILE* fpasm, int es_referencia_1, int es_referencia_2, int etiqueta){
  if(fpasm == NULL){
    return;
  }

  fprintf(fpasm,";Cargar la segunda expresion en edx\n\tpop dword edx\n");
  if(es_referencia_1 == INT){
    fprintf(fpasm, "\tmov dword edx, [edx]\n");
  }

  fprintf(fpasm,";Cargar la primera expresion en eax\n\tpop dword eax\n");
  if(es_referencia_2 == INT){
    fprintf(fpasm, "\tmov dword eax, [eax]\n");
  }

  fprintf(fpasm,";Comparar y apilar el resultado\n");
  fprintf(fpasm,"\tcmp eax, edx\n\tjne near distinto%d\n\tpush dword 0\n\tjmp near fin_distinto%d\n", etiqueta, etiqueta);
  fprintf(fpasm,"distinto%d:\n\tpush dword 1\n\tfin_distinto%d:\n", etiqueta, etiqueta);
}

void comparacion_menorigual(FILE* fpasm, int es_referencia_1, int es_referencia_2, int etiqueta){
  if(fpasm == NULL){
    return;
  }

  fprintf(fpasm,";Cargar la segunda expresion en edx\n\tpop dword edx\n");
  if(es_referencia_1 == INT){
    fprintf(fpasm, "\tmov dword edx, [edx]\n");
  }

  fprintf(fpasm,";Cargar la primera expresion en eax\n\tpop dword eax\n");
  if(es_referencia_2 == INT){
    fprintf(fpasm, "\tmov dword eax, [eax]\n");
  }

  fprintf(fpasm,";Comparar y apilar el resultado\n");
  fprintf(fpasm,"\tcmp eax, edx\n\tjle near menorigual%d\n\tpush dword 0\n\tjmp near fin_menorigual%d\n", etiqueta, etiqueta);
  fprintf(fpasm,"menorigual%d:\n\tpush dword 1\n\tfin_menorigual%d:\n", etiqueta, etiqueta);
}

void comparacion_mayorigual(FILE* fpasm, int es_referencia_1, int es_referencia_2, int etiqueta){
  if(fpasm == NULL){
    return;
  }

  fprintf(fpasm,";Cargar la segunda expresion en edx\n\tpop dword edx\n");
  if(es_referencia_1 == INT){
    fprintf(fpasm, "\tmov dword edx, [edx]\n");
  }

  fprintf(fpasm,";Cargar la primera expresion en eax\n\tpop dword eax\n");
  if(es_referencia_2 == INT){
    fprintf(fpasm, "\tmov dword eax, [eax]\n");
  }

  fprintf(fpasm,";Comparar y apilar el resultado\n");
  fprintf(fpasm,"\tcmp eax, edx\n\tjge near mayorigual%d\n\tpush dword 0\n\tjmp near fin_mayorigual%d\n", etiqueta, etiqueta);
  fprintf(fpasm,"mayorigual%d:\n\tpush dword 1\n\tfin_mayorigual%d:\n", etiqueta, etiqueta);
}

void comparacion_menor(FILE* fpasm, int es_referencia_1, int es_referencia_2, int etiqueta){
  if(fpasm == NULL){
    return;
  }

  fprintf(fpasm,";Cargar la segunda expresion en edx\n\tpop dword edx\n");
  if(es_referencia_1 == 1){
    fprintf(fpasm, "\tmov dword edx, [edx]\n");
  }

  fprintf(fpasm,";Cargar la primera expresion en eax\n\tpop dword eax\n");
  if(es_referencia_2 == 1){
    fprintf(fpasm, "\tmov dword eax, [eax]\n");
  }

  fprintf(fpasm,";Comparar y apilar el resultado\n");
  fprintf(fpasm,"\tcmp eax, edx\n\tjl near menor%d\n\tpush dword 0\n\tjmp near fin_menor%d\n", etiqueta, etiqueta);
  fprintf(fpasm,"menor%d:\n\tpush dword 1\n\tfin_menor%d:\n", etiqueta, etiqueta);
}

void comparacion_mayor(FILE* fpasm, int es_referencia_1, int es_referencia_2, int etiqueta){
  if(fpasm == NULL){
    return;
  }

  fprintf(fpasm,";Cargar la segunda expresion en edx\n\tpop dword edx\n");
  if(es_referencia_1 == INT){
    fprintf(fpasm, "\tmov dword edx, [edx]\n");
  }

  fprintf(fpasm,";Cargar la primera expresion en eax\n\tpop dword eax\n");
  if(es_referencia_2 == INT){
    fprintf(fpasm, "\tmov dword eax, [eax]\n");
  }

  fprintf(fpasm,";Comparar y apilar el resultado\n");
  fprintf(fpasm,"\tcmp eax, edx\n\tjg near mayor%d\n\tpush dword 0\n\tjmp near fin_mayor%d\n", etiqueta, etiqueta);
  fprintf(fpasm,"mayor%d:\n\tpush dword 1\n\tfin_mayor%d:\n", etiqueta, etiqueta);
}
void condicion_si_estrella_roja(FILE* fpasm, int es_direccion,int etiqueta){
  if(fpasm == NULL){
    return;
  }
  fprintf(fpasm,"\tpop dword eax\n");
  if(es_direccion == 1){
    fprintf(fpasm,"\tmov eax, [eax]\n");
  }
  fprintf(fpasm,"\tcmp eax, 0\n\tje near fin_si%d ;es $$.etiqueta\n",etiqueta);
}
void condicion_si_estrella_azul_una_condicion(FILE* fpasm, int etiqueta){
  if(fpasm == NULL){
    return;
  }
  fprintf(fpasm,"\tfin_si%d:\n",etiqueta);
}
void condicion_si_estrella_verde(FILE* fpasm, int etiqueta){
  if(fpasm == NULL){
    return;
  }
  fprintf(fpasm,"\tjmp near fin_sino%d\n\tfin_si%d:\n\n",etiqueta,etiqueta);
}
void condicion_si_estrella_azul_mas_condiciones(FILE* fpasm, int etiqueta){
  if(fpasm == NULL){
    return;
  }
  fprintf(fpasm,"\tfin_sino%d:\n",etiqueta);
}
void condicion_bucle_estrella_verde(FILE* fpasm,int es_direccion, int etiqueta){
  if(fpasm == NULL){
    return;
  }
  fprintf(fpasm,"\tpop dword eax\n");
  if(es_direccion == 1){
    fprintf(fpasm,"\tmov eax, [eax]\n");
  }
  fprintf(fpasm,"\tcmp eax, 0\n\tje near fin_while%d ;es $$.etiqueta\n",etiqueta);
}
void condicion_bucle_estrella_roja(FILE* fpasm, int etiqueta){
  if(fpasm == NULL){
    return;
  }
  fprintf(fpasm,"\tinicio_while%d:\n\n",etiqueta);
}
void condicion_bucle_estrella_azul(FILE* fpasm, int etiqueta){
  if(fpasm == NULL){
    return;
  }
  fprintf(fpasm,"\tjmp near inicio_while%d\n\tfin_while%d:\n\n",etiqueta,etiqueta);
}
void llamada_funcion(FILE *fpasm, char* nombre_funcion,int num_parametros){
  if(fpasm == NULL){
    return;
  }
  fprintf(fpasm,"\tcall _%s\n\tadd esp,4 * %d\n\tpush dword eax\n",nombre_funcion,num_parametros);
}
void funcion(FILE * fpasm, char*nombre_funcion,int num_variables){
  if(fpasm == NULL){
    return;
  }
  fprintf(fpasm,"\t_%s:\n\tpush ebp\n\tmov ebp,esp\n\tsub esp, 4*%d\n",nombre_funcion,num_variables);

}
void retorno_funcion(FILE * fpasm, int es_direccion){
  if(fpasm == NULL){
    return;
  }
  fprintf(fpasm,"\tpop dword eax\n");
  if(es_direccion == 1){
    fprintf(fpasm,"\tmov eax, [eax]\n");
  }
  fprintf(fpasm,"\tmov dword esp,ebp\n\tpop dword ebp\n\tret\n");

}

void variable_contador(FILE * fpasm){
  if(fpasm == NULL){
    return;
  }
  fprintf(fpasm,"\tmov dword ecx, 0\n");

}

void iterable_vector(FILE * fpasm, char * nombre_vector,char * nombre_funcion,int es_direccion,int no_veces, int longitud){
  int i;

  if(fpasm == NULL){
    return;
  }

  for(i=0; i < longitud; i++){

    fprintf(fpasm,"\t%s_%d_%d: push dword %d\n",nombre_funcion,no_veces,i,i);
    comprobar_indices(fpasm,es_direccion,longitud);
    indexar_vector(fpasm,nombre_vector,1);
    llamada_funcion(fpasm,nombre_funcion,1);
    fprintf(fpasm,"\n;Cargar en eax la parte derecha de la asignacion\n\tpop dword eax\n");
    fprintf(fpasm,"\n;Comparamos si el valor es true o false\n\tcmp eax, 1\n");
    if(i+1 == longitud){
      fprintf(fpasm,"\n;Si es true nos situamos en incrementar_marcador\n\tjne near fin_%s_%d\n",nombre_funcion,no_veces);
    }else{
      fprintf(fpasm,"\n;Si es true nos situamos en incrementar_marcador\n\tjne near %s_%d_%d\n",nombre_funcion,no_veces,i+1);
    }
    fprintf(fpasm,"\n;Incrementamos el marcador en 1\n\tinc ecx\n");

  }

  fprintf(fpasm,"\n;Guardamos el marcador finalmente para ser mostrado por pantalla\n\tfin_%s_%d:push dword ecx\n",nombre_funcion,no_veces);

}
void sumar_vectorial(FILE* fpasm){
  if(fpasm == NULL){
    return;
  }
  fprintf(fpasm, "\tpop dword eax\n");

  fprintf(fpasm, "\tadd eax, ecx\n");
  fprintf(fpasm,"\tpush dword eax\n");
}
void asignar_expresion_a_vector_vectorial(FILE *fpasm){
  if(fpasm == NULL){
    return;
  }
  fprintf(fpasm,";Cargar en eax la parte derecha de la asignacion\n\tpop dword eax\n");

  fprintf(fpasm, ";Cargar en edx la parte izquierda de la asignacion\n\tpop dword edx\n" );
  fprintf(fpasm, ";Hacer la asignacion efectiva\n\tmov dword [edx],eax\n");

}
void indexar_vector_vectorial(FILE *fpasm, char * lexema){
  if(fpasm == NULL){
    return;
  }
  fprintf(fpasm,";Cargar en edx la direccion de inicio del vector\n\tmov dword edx, _%s\n",lexema);
  fprintf(fpasm, ";Cargar en eax la dirección del elemento indexado\n\tlea eax, [edx +eax *4]\n" );
  fprintf(fpasm,"\tpush dword eax\n");
  fprintf(fpasm, ";Apilar la dirección del elemento indexado\n\tpush dword [eax]\n");;


}

void comparacion_igual_compare(FILE* fpasm, int es_referencia_1, int es_referencia_2, int etiqueta){
  if(fpasm == NULL){
    return;
  }

  fprintf(fpasm,";Cargar la segunda expresion en edx\n\tpop dword edx\n");
  if(es_referencia_1 == INT){
    fprintf(fpasm, "\tmov dword edx, [edx]\n");
  }

  fprintf(fpasm,";Cargar la primera expresion en eax\n\tpop dword eax\n");
  if(es_referencia_2 == INT){
    fprintf(fpasm, "\tmov dword eax, [eax]\n");
  }

  fprintf(fpasm,";Comparar y apilar el resultado\n");
  fprintf(fpasm,"\tcmp eax, edx\n\tje near equal%d\n\tcmp eax, edx\n\tjl near less%d\n\tcmp eax, edx\n\tjg near greater%d\n", etiqueta, etiqueta,etiqueta);
}
