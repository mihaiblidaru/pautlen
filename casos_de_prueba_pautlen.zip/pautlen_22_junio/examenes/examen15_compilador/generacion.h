#ifndef GENERACION_H
#define GENERACION_H

#include <stdio.h>
#include "tablaHash.h"

/* FUNCIONES DE ESCRITURA CODIGO INICIAL .ASM Y ASIGNACION DE VARIABLES */
void escribir_cabecera_compatibilidad(FILE* fpasm);
void escribir_subseccion_data(FILE* fpasm);
void escribir_cabecera_bss(FILE* fpasm);
void declarar_variable(FILE* fpasm, char * nombre,  int tipo,  int tamano);
void escribir_segmento_codigo(FILE* fpasm);
void escribir_inicio_main(FILE* fpasm);
void escribir_fin(FILE* fpasm);
void escribir_operando(FILE* fpasm, char* nombre, int es_var);

/* FUNCIONES ARITMÉTICO-LÓGICAS BINARIAS */

void sumar(FILE* fpasm, int es_referencia_1, int es_referencia_2);
void restar(FILE* fpasm, int es_referencia_1, int es_referencia_2);
void multiplicar(FILE* fpasm, int es_referencia_1, int es_referencia_2);
void dividir(FILE* fpasm, int es_referencia_1, int es_referencia_2);
void o(FILE* fpasm, int es_referencia_1, int es_referencia_2);
void y(FILE* fpasm, int es_referencia_1, int es_referencia_2);
void cambiar_signo(FILE* fpasm, int es_referencia);
void no(FILE* fpasm, int es_referencia, int cuantos_no);

/* FUNCIONES DE ESCRITURA Y LECTURA */
void leer(FILE* fpasm, char* nombre, int tipo);
void escribir(FILE* fpasm, int es_referencia, int tipo);

void comprobar_indices(FILE *fpasm, int es_referencia,int tamano);
void indexar_vector(FILE *fpasm, char * lexema, int explist);
void asignar_expresion_a_elemento_identificador(FILE *fpasm,char * nombre, int es_referencia);
void asignar_expresion_a_vector(FILE *fpasm, int es_referencia);
void asignar_expresion_a_elemento_identificador_funcion(FILE *fpasm, int es_referencia,int num_variable);

void comparacion_igual(FILE* fpasm, int es_referencia_1, int es_referencia_2, int etiqueta);
void comparacion_distinto(FILE* fpasm, int es_referencia_1, int es_referencia_2, int etiqueta);
void comparacion_menorigual(FILE* fpasm, int es_referencia_1, int es_referencia_2, int etiqueta);
void comparacion_mayorigual(FILE* fpasm, int es_referencia_1, int es_referencia_2, int etiqueta);
void comparacion_menor(FILE* fpasm, int es_referencia_1, int es_referencia_2, int etiqueta);
void comparacion_mayor(FILE* fpasm, int es_referencia_1, int es_referencia_2, int etiqueta);

void condicion_si_estrella_roja(FILE* fpasm, int es_direccion,int etiqueta);
void condicion_si_estrella_azul_una_condicion(FILE* fpasm, int etiqueta);
void condicion_si_estrella_verde(FILE* fpasm, int etiqueta);
void condicion_si_estrella_azul_mas_condiciones(FILE* fpasm, int etiqueta);
void condicion_bucle_estrella_roja(FILE* fpasm, int etiqueta);
void condicion_bucle_estrella_verde(FILE* fpasm,int es_direccion, int etiqueta);
void condicion_bucle_estrella_azul(FILE* fpasm, int etiqueta);

void llamada_funcion(FILE *fpasm, char* nombre_funcion,int num_parametros);
void funcion(FILE * fpasm, char*nombre_funcion,int num_variables);
void retorno_funcion(FILE * fpasm, int es_direccion);

void variable_contador(FILE * fpasm);
void iterable_vector(FILE * fpasm, char * nombre_vector,char * nombre_funcion,int es_direccion,int no_veces, int longitud);
void sumar_vectorial(FILE* fpasm);
void asignar_expresion_a_vector_vectorial(FILE *fpasm);
void indexar_vector_vectorial(FILE *fpasm, char * lexema);
void comparacion_igual_compare(FILE* fpasm, int es_referencia_1, int es_referencia_2, int etiqueta);


#endif
