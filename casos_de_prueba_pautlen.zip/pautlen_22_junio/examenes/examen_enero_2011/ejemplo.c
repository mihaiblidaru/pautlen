main {

int x, y, z;
x = 2;
y = 3;
z = 2*x^y;
printf(z);

}
