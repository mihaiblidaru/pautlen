Incrementar
	x += 8;