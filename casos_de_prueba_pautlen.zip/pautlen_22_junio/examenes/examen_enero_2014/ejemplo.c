// Tratamiento de funciones: recursividad

main
{
// Declaraciones

int x, y;
boolean b;

// Sentencias
    scanf x;
    y = 5;
    compare x with y
    {
        less
            compare x with 0
            {
                less
                    printf 5;
                equal
                    printf 6;
                greater
                    printf 7;
            }
        equal
            printf 2;
        greater
            printf 3;
    }
}