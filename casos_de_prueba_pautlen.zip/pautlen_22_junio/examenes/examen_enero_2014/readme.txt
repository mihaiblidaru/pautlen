Comparacion de enteros:
	compare x with y
	{
		less
			<sentencias>
		equal
			<sentencias>
		greater
			<sentencias>
	}