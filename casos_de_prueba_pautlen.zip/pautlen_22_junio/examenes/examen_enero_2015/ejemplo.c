// Tratamiento de funciones: recursividad

main
{
// Declaraciones
    array int [4] v;

// Sentencias
    init v {-10;-20;-30;-40};
    printf v[0];
    printf v[1];
    printf v[2];
    printf v[3];
}