Inicializacion de vectores:
	init v{1;2;3;4};