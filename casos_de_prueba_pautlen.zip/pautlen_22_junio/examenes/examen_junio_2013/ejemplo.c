// Tratamiento de funciones: recursividad

main
{
// Declaraciones

    int x;
    boolean b;

// Sentencias
    x = 1;
    b = true;
    for(x = x; 5)
    {
        printf 1;
    }
    printf x;
}