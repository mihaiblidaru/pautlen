// Tratamiento de funciones: recursividad

main
{
 int k = 4,f, j=2;
 
function int suma(int m;int n){
 int x=8,y;
 boolean a = false, b= true;

 printf x;
 printf a;
 printf b;

 return m+n;
}


 printf suma(j,k);
}
