// Tratamiento de funciones: recursividad

main
{
// Declaraciones

    int resultado, x;

// Funciones
    function int suma(int x)
    {
        int sum;
        if((x == 1))
        {
            return 1;
        }
        sum = suma(x-1);
        return x + sum;
    }

// Sentencias
    scanf x;
    resultado = suma (x);

    printf resultado;
}