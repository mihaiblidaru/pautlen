#include "generacion.h"

void escribir_cabecera_compatibilidad(FILE* fpasm)
{
	/*Por ahora puede estar vacia*/
	fprintf(fpasm, ";Cabecera de compatibilidad\n");
}

void escribir_subseccion_data(FILE* fpasm)
{
	fprintf(fpasm, "segment .data\nzeroDivision db \"Division por cero\",0\nmensaje db \"Indice fuera de rango\", 0\n");
}

void escribir_cabecera_bss(FILE* fpasm)
{
	fprintf(fpasm, "segment .bss\n");
	fprintf(fpasm, "\t__esp resd 1\n");
}



/*PREGUNTAR A LA PROFE*/
void declarar_variable(FILE* fpasm, char * nombre,  int tipo,  int tamano)
{
	if(tipo == ENTERO)
	{
		fprintf(fpasm, "\t_%s resd %d\n", nombre, tamano);
	}
	else if (tipo == BOOLEANO)
	{
		fprintf(fpasm, "\t_%s resd %d\n", nombre, tamano);
	}
}

void escribir_segmento_codigo(FILE* fpasm)
{
	fprintf(fpasm, "segment .text\nglobal main\nextern print_int, print_boolean, print_string, print_blank, print_endofline, scan_int, scan_boolean\n");
}

void escribir_inicio_main(FILE* fpasm)
{
	fprintf(fpasm, "main:\n\tmov dword [__esp], esp\n");
}

void escribir_fin(FILE* fpasm)
{
	fprintf(fpasm, "\tjmp fin\n");
	fprintf(fpasm, "_cero_div:\n");
	fprintf(fpasm, "\tpush dword zeroDivision\n");
	fprintf(fpasm, "\tcall print_string\n");
	fprintf(fpasm, "\tadd esp, 4\n");
	fprintf(fpasm, "\tcall print_endofline\n");
	fprintf(fpasm, "\tjmp fin\n");
	fprintf(fpasm, "mensaje_1:\n");
	fprintf(fpasm, "\tpush dword mensaje\n");
	fprintf(fpasm, "\tcall print_string\n");
	fprintf(fpasm, "\tadd esp, 4\n");
	fprintf(fpasm, "\tcall print_endofline\n");
	fprintf(fpasm, "\tjmp near fin\n");
	fprintf(fpasm, "fin:\n");
	fprintf(fpasm, "\tmov esp, dword [__esp]\n");
	fprintf(fpasm, "\tret\n");
}

void escribir_operando(FILE* fpasm, char* nombre, int es_var)
{
	if(es_var == 0)
		fprintf(fpasm, "\tpush dword %s\n", nombre);
	else
		fprintf(fpasm, "\tpush dword _%s\n", nombre);
}

void escribir_operando_funcion(FILE* fpasm, char* nombre, int es_var)
{
	if(es_var == 0)
		fprintf(fpasm, "\tpush dword %s\n", nombre);
	else
		fprintf(fpasm, "\tpush dword [_%s]\n", nombre);
}


void asignar(FILE* fpasm, char* nombre, int es_referencia)
{
	if(es_referencia == 0) /*Valor*/
		fprintf(fpasm, "\tpop dword [_%s]\n", nombre);
	else if(es_referencia == 1) /*Referencia*/
		fprintf(fpasm, "\tpop dword _%s\n", nombre);
}

void sumar(FILE* fpasm, int es_referencia_1, int es_referencia_2)
{
	fprintf(fpasm, "\tpop dword ebx\n");
	if(es_referencia_2 == 1)
	{
		
		fprintf(fpasm, "\tmov ebx, dword [ebx]\n");

	}
	fprintf(fpasm, "\tpop dword eax\n");
	if(es_referencia_1 == 1)
	{
		
		fprintf(fpasm, "\tmov eax, dword [eax]\n");

	}

	fprintf(fpasm, "\tadd eax, ebx\n");
	fprintf(fpasm, "\tpush eax\n");
}

void restar(FILE* fpasm, int es_referencia_1, int es_referencia_2)
{
	fprintf(fpasm, "\tpop dword ebx\n");
	if(es_referencia_2 == 1)
	{
		
		fprintf(fpasm, "\tmov ebx, dword [ebx]\n");

	}
	fprintf(fpasm, "\tpop dword eax\n");
	if(es_referencia_1 == 1)
	{
		
		fprintf(fpasm, "\tmov eax, dword [eax]\n");

	}

	fprintf(fpasm, "\tsub eax, ebx\n");
	fprintf(fpasm, "\tpush eax\n");
}

void multiplicar(FILE* fpasm, int es_referencia_1, int es_referencia_2)
{
	fprintf(fpasm, "\tpop dword ebx\n");
	if(es_referencia_2 == 1)
	{
		
		fprintf(fpasm, "\tmov ebx, dword [ebx]\n");

	}
	fprintf(fpasm, "\tpop dword eax\n");
	if(es_referencia_1 == 1)
	{
		
		fprintf(fpasm, "\tmov eax, dword [eax]\n");

	}

	fprintf(fpasm, "\timul ebx\n");
	fprintf(fpasm, "\tpush eax\n");
}


void dividir(FILE* fpasm, int es_referencia_1, int es_referencia_2)
{
	fprintf(fpasm, "\tpop dword ebx\n");
	if(es_referencia_2 == 1)
	{
		
		fprintf(fpasm, "\tmov ebx, dword [ebx]\n");

	}
	fprintf(fpasm, "\tpop dword eax\n");
	if(es_referencia_1 == 1)
	{
		
		fprintf(fpasm, "\tmov eax, dword [eax]\n");

	}
	fprintf(fpasm, "\tcdq\n");
	fprintf(fpasm, "\tcmp ebx, 0\n");
	fprintf(fpasm, "\tje _cero_div\n");
	fprintf(fpasm, "\tidiv ebx\n");
	fprintf(fpasm, "\tpush dword eax\n");
}

void o(FILE* fpasm, int es_referencia_1, int es_referencia_2)
{
	fprintf(fpasm, "\tpop dword ebx\n");
	if(es_referencia_2 == 1)
	{
		
		fprintf(fpasm, "\tmov ebx, dword [ebx]\n");

	}
	fprintf(fpasm, "\tpop dword eax\n");
	if(es_referencia_1 == 1)
	{
		
		fprintf(fpasm, "\tmov eax, dword [eax]\n");

	}

	fprintf(fpasm, "\tor eax, ebx\n");
	fprintf(fpasm, "\tpush eax\n");
}

void y(FILE* fpasm, int es_referencia_1, int es_referencia_2)
{
	fprintf(fpasm, "\tpop dword ebx\n");
	if(es_referencia_2 == 1)
	{
		
		fprintf(fpasm, "\tmov ebx, dword [ebx]\n");

	}
	fprintf(fpasm, "\tpop dword eax\n");
	if(es_referencia_1 == 1)
	{
		
		fprintf(fpasm, "\tmov eax, dword [eax]\n");

	}

	fprintf(fpasm, "\tand eax, ebx\n");
	fprintf(fpasm, "\tpush eax\n");
}

void cambiar_signo(FILE* fpasm, int es_referencia)
{
	if(es_referencia == 0)
	{
		fprintf(fpasm, "\tpop dword eax\n");
		fprintf(fpasm, "\tneg eax\n");
		fprintf(fpasm, "\tpush eax\n");
	}else{
		fprintf(fpasm, "\tpop dword eax\n");
		fprintf(fpasm, "\tmov ebx, dword [eax]\n");
		fprintf(fpasm, "\tneg ebx\n");
		fprintf(fpasm, "\tpush ebx\n");
	}
}

void no(FILE* fpasm, int es_referencia, int cuantos_no)
{
	fprintf(fpasm, "\tpop dword eax\n");
	if (es_referencia == 1){
		fprintf(fpasm, "\tmov ebx, dword [eax]\n");
		fprintf(fpasm, "\tcmp ebx, 0\n");
	}else{
		fprintf(fpasm, "\tcmp eax, 0\n");
	}
	fprintf(fpasm, "\tje _uno_%d\n",cuantos_no);
	fprintf(fpasm, "\tpush dword 0\n");
	fprintf(fpasm, "\tjmp _no_fin_%d\n",cuantos_no);
	fprintf(fpasm, "\t_uno_%d:\n",cuantos_no);
	fprintf(fpasm, "\tpush dword 1\n");
	fprintf(fpasm, "\t_no_fin_%d:\n",cuantos_no);
}

void igual(FILE * fpasm, int es_referencia1, int es_referencia2, int contador)
{
	fprintf(fpasm, "\tpop dword ebx\n");
	if(es_referencia2 == 1)
	{
		
		fprintf(fpasm, "\tmov ebx, dword [ebx]\n");

	}
	fprintf(fpasm, "\tpop dword eax\n");
	if(es_referencia1 == 1)
	{
		
		fprintf(fpasm, "\tmov eax, dword [eax]\n");

	}
	fprintf(fpasm, "\tcmp eax, ebx\n");
	fprintf(fpasm, "\tje near igual%d\n", contador);
	fprintf(fpasm, "\tpush dword 0\n");
	fprintf(fpasm, "\tjmp near fin_igual%d\n", contador);
	fprintf(fpasm, "igual%d:\n\tpush dword 1\n", contador);
	fprintf(fpasm, "fin_igual%d:\n", contador);			
}

void distinto(FILE * fpasm, int es_referencia1, int es_referencia2, int contador)
{
	fprintf(fpasm, "\tpop dword ebx\n");
	if(es_referencia2 == 1)
	{
		
		fprintf(fpasm, "\tmov ebx, dword [ebx]\n");

	}
	fprintf(fpasm, "\tpop dword eax\n");
	if(es_referencia1 == 1)
	{
		
		fprintf(fpasm, "\tmov eax, dword [eax]\n");

	}
	fprintf(fpasm, "\tcmp eax, ebx\n");
	fprintf(fpasm, "\tjne near distinto%d\n", contador);
	fprintf(fpasm, "\tpush dword 0\n");
	fprintf(fpasm, "\tjmp near fin_distinto%d\n", contador);
	fprintf(fpasm, "distinto%d:\n\tpush dword 1\n", contador);
	fprintf(fpasm, "fin_distinto%d:\n", contador);			
}

void menorigual(FILE * fpasm, int es_referencia1, int es_referencia2, int contador)
{
	fprintf(fpasm, "\tpop dword ebx\n");
	if(es_referencia2 == 1)
	{
		
		fprintf(fpasm, "\tmov ebx, dword [ebx]\n");

	}
	fprintf(fpasm, "\tpop dword eax\n");
	if(es_referencia1 == 1)
	{
		
		fprintf(fpasm, "\tmov eax, dword [eax]\n");

	}
	fprintf(fpasm, "\tcmp eax, ebx\n");
	fprintf(fpasm, "\tjle near menorigual%d\n", contador);
	fprintf(fpasm, "\tpush dword 0\n");
	fprintf(fpasm, "\tjmp near fin_menorigual%d\n", contador);
	fprintf(fpasm, "menorigual%d:\n\tpush dword 1\n", contador);
	fprintf(fpasm, "fin_menorigual%d:\n", contador);			
}

void mayorigual(FILE * fpasm, int es_referencia1, int es_referencia2, int contador)
{
	fprintf(fpasm, "\tpop dword ebx\n");
	if(es_referencia2 == 1)
	{
		
		fprintf(fpasm, "\tmov ebx, dword [ebx]\n");

	}
	fprintf(fpasm, "\tpop dword eax\n");
	if(es_referencia1 == 1)
	{
		
		fprintf(fpasm, "\tmov eax, dword [eax]\n");

	}
	fprintf(fpasm, "\tcmp eax, ebx\n");
	fprintf(fpasm, "\tjge near mayorigual%d\n", contador);
	fprintf(fpasm, "\tpush dword 0\n");
	fprintf(fpasm, "\tjmp near fin_mayorigual%d\n", contador);
	fprintf(fpasm, "mayorigual%d:\n\tpush dword 1\n", contador);
	fprintf(fpasm, "fin_mayorigual%d:\n", contador);			
}

void menor(FILE * fpasm, int es_referencia1, int es_referencia2, int contador)
{
	fprintf(fpasm, "\tpop dword ebx\n");
	if(es_referencia2 == 1)
	{
		
		fprintf(fpasm, "\tmov ebx, dword [ebx]\n");

	}
	fprintf(fpasm, "\tpop dword eax\n");
	if(es_referencia1 == 1)
	{
		
		fprintf(fpasm, "\tmov eax, dword [eax]\n");

	}
	fprintf(fpasm, "\tcmp eax, ebx\n");
	fprintf(fpasm, "\tjl near menor%d\n", contador);
	fprintf(fpasm, "\tpush dword 0\n");
	fprintf(fpasm, "\tjmp near fin_menor%d\n", contador);
	fprintf(fpasm, "menor%d:\n\tpush dword 1\n", contador);
	fprintf(fpasm, "fin_menor%d:\n", contador);			
}

void mayor(FILE * fpasm, int es_referencia1, int es_referencia2, int contador)
{
	fprintf(fpasm, "\tpop dword ebx\n");
	if(es_referencia2 == 1)
	{
		
		fprintf(fpasm, "\tmov ebx, dword [ebx]\n");

	}
	fprintf(fpasm, "\tpop dword eax\n");
	if(es_referencia1 == 1)
	{
		
		fprintf(fpasm, "\tmov eax, dword [eax]\n");

	}
	fprintf(fpasm, "\tcmp eax, ebx\n");
	fprintf(fpasm, "\tjg near mayor%d\n", contador);
	fprintf(fpasm, "\tpush dword 0\n");
	fprintf(fpasm, "\tjmp near fin_mayor%d\n", contador);
	fprintf(fpasm, "mayor%d:\n\tpush dword 1\n", contador);
	fprintf(fpasm, "fin_mayor%d:\n", contador);			
}



void leer(FILE* fpasm, char* nombre, int tipo)
{
	fprintf(fpasm, "\tpush dword _%s\n", nombre);

	if(tipo == BOOLEANO)
	{
		fprintf(fpasm, "\tcall scan_boolean\n");
	}
	else if(tipo == ENTERO)
	{	
		fprintf(fpasm, "\tcall scan_int\n");
	}

	fprintf(fpasm, "\tadd esp, 4\n");
}

void escribir(FILE* fpasm, int es_referencia, int tipo)
{
	fprintf(fpasm, "\tpop dword eax\n");
	if(es_referencia == 0)
	{
		fprintf(fpasm, "\tpush eax\n");

	}
	else
	{
		fprintf(fpasm, "\tpush dword [eax]\n");
	}

	if(tipo == BOOLEANO)
	{
		fprintf(fpasm, "\tcall print_boolean\n");
	}
	else if(tipo == ENTERO)
	{	
		fprintf(fpasm, "\tcall print_int\n");
	}
	
	fprintf(fpasm, "\tadd esp, 4\n");
	fprintf(fpasm, "\tcall print_endofline\n");
}

void escribirLLamadaFuncion(FILE *fpasm, char * nombre, int num)
{
	fprintf(fpasm, "\tcall _%s\n", nombre);
	fprintf(fpasm, "\tadd esp, %d\n", 4*num);
	fprintf(fpasm, "\tpush dword eax\n");
}
