#include <stdio.h>
#include <string.h>
#include <stdlib.h>

extern FILE *yyin, *yyout; /*Ficharos de entrada y salida*/
extern int yyparse (void);

int main(int argc, char const *argv[])
{
	if(argc != 3)
	{
		printf("USE: %s <file_in> <file_out>\n", argv[0]);
		return 1;
	}

	yyin=fopen(argv[1],"r");
	if(!yyin)
	{
		return 1;
	}

	yyout=fopen(argv[2],"w");
	if(!yyout)
	{
		fclose(yyin);
		return 1;
	}
	
	yyparse();

	fclose(yyin);
	fclose(yyout);
	return 0;
}