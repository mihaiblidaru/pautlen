#include "table.h"
#include "tablaHash.h"
#include <stdio.h>
#include <stdlib.h>

struct _Table
{
	int tam;
	TABLA_HASH * global;
	TABLA_HASH * local;
};

Table * crearTabla(int tam)
{
	Table * table = NULL;
	table = (Table *) malloc(sizeof(Table));
	if(table == NULL)
		return NULL;
	table->global = crear_tabla(tam);
	if(table->global == NULL)
	{
		free(table);
		return NULL;
	}
	table->local = NULL;
	table->tam = tam;
	return table;
}

void eliminarTabla(Table * table)
{
	if(table == NULL)
		return;
	if(table->local != NULL)
		liberar_tabla(table->local);
	if(table->global != NULL)
		liberar_tabla(table->global);
	free(table);
}

int insertarElemento(Table * table, const char *lexema, CATEGORIA categ, TIPO tipo, CLASE clase, int adic1, int adic2)
{
	STATUS status;
	/*La variable es de ambito local*/
	if(table->local != NULL)
	{
		if(clase == VECTOR)
			return -1;
		if(buscar_simbolo(table->local, lexema) != NULL)
		{
			return -1;
		}
		status = insertar_simbolo(table->local, lexema, categ, tipo, clase, adic1, adic2);
		if(status == OK)/*Se ha insertado con exito*/
		{
			return 0;
		}
		else/*Ha habido un error en la inserción*/
		{
			return -1;
		}
	}
	else
	{
		if(buscar_simbolo(table->global, lexema) != NULL)
		{
			return -1;
		}
		status = insertar_simbolo(table->global, lexema, categ, tipo, clase, adic1, adic2);
		if(status == OK)/*Se ha insertado con exito*/
		{
			return 0;
		}
		else/*Ha habido un error en la inserción*/
		{
			return -1;
		}
	}
}

int buscarEnLocal(Table * table, const char *lexema)
{
	INFO_SIMBOLO * simbolo = NULL;
	if(table->local == NULL)/*Solo hay ambito global*/
	{
		simbolo = buscar_simbolo(table->global, lexema);
		if(simbolo == NULL)
		{
			return -1;
		}
		else
		{
			return 1;
		}
	}
	else/*Hay ambito global y local*/
	{
		simbolo = buscar_simbolo(table->local, lexema);/*Se da prioridad al ambito local*/
		if(simbolo == NULL)
		{
			return -1;
		}
		else
		{
			return 1;
		}
	}
	return -1;
}

int buscarEnGlobal(Table * table, const char *lexema)
{
	INFO_SIMBOLO * simbolo = NULL;
	simbolo = buscar_simbolo(table->global, lexema);
	if(simbolo == NULL)
	{
		return -1;
	}
	else
	{
		return 1;
	}
	return -1;
}

int buscarElemento(Table * table, const char *lexema)
{
	INFO_SIMBOLO * simbolo = NULL;
	if(table->local == NULL)/*Solo hay ambito global*/
	{
		simbolo = buscar_simbolo(table->global, lexema);
		if(simbolo == NULL)
		{
			return -1;
		}
		else
		{
			return get_adicional1(simbolo);
		}
	}
	else/*Hay ambito global y local*/
	{
		simbolo = buscar_simbolo(table->local, lexema);/*Se da prioridad al ambito local*/
		if(simbolo == NULL)
		{
			simbolo = buscar_simbolo(table->global, lexema);
			if(simbolo == NULL)
			{
				return -1;
			}
			else
			{
				return get_adicional1(simbolo);
			}
		}
		else
		{
			return get_adicional1(simbolo);
		}
	}
	return -1;
}

int obtenerTipoFuncion(Table * table, const char *lexema)
{
	INFO_SIMBOLO * simbolo = NULL;
	if(table->local == NULL)/*Solo hay ambito global*/
	{
		simbolo = buscar_simbolo(table->global, lexema);
		if(simbolo == NULL)
		{
			return -1;
		}
		else
		{
			return simbolo->tipo;
		}
	}
	else/*Hay ambito global y local*/
	{
		simbolo = buscar_simbolo(table->local, lexema);/*Se da prioridad al ambito local*/
		if(simbolo == NULL)
		{
			simbolo = buscar_simbolo(table->global, lexema);
			if(simbolo == NULL)
			{
				return -1;
			}
			else
			{
				return simbolo->tipo;
			}
		}
		else
		{
			return simbolo->tipo;
		}
	}
	return -1;
}

int localAbierto(Table * table)
{
	if(table->local == NULL)
		return 0;
	return 1;
}

int obtenerCategoria(Table * table, const char *lexema)
{
	INFO_SIMBOLO * simbolo = NULL;
	if(table->local == NULL)/*Solo hay ambito global*/
	{
		simbolo = buscar_simbolo(table->global, lexema);
		if(simbolo == NULL)
		{
			return -1;
		}
		else
		{
			return simbolo->categoria;
		}
	}
	else/*Hay ambito global y local*/
	{
		simbolo = buscar_simbolo(table->local, lexema);/*Se da prioridad al ambito local*/
		if(simbolo == NULL)
		{
			simbolo = buscar_simbolo(table->global, lexema);
			if(simbolo == NULL)
			{
				return -1;
			}
			else
			{
				return simbolo->categoria;
			}
		}
		else
		{
			return simbolo->categoria;
		}
	}
	return -1;
}

int obtenerClase(Table * table, const char *lexema)
{
	INFO_SIMBOLO * simbolo = NULL;
	if(table->local == NULL)/*Solo hay ambito global*/
	{
		simbolo = buscar_simbolo(table->global, lexema);
		if(simbolo == NULL)
		{
			return -1;
		}
		else
		{
			return simbolo->clase;
		}
	}
	else/*Hay ambito global y local*/
	{
		simbolo = buscar_simbolo(table->local, lexema);/*Se da prioridad al ambito local*/
		if(simbolo == NULL)
		{
			simbolo = buscar_simbolo(table->global, lexema);
			if(simbolo == NULL)
			{
				return -1;
			}
			else
			{
				return simbolo->clase;
			}
		}
		else
		{
			return simbolo->clase;
		}
	}
	return -1;
}

int obtenerNumParametros(Table * table, const char *lexema)
{
	INFO_SIMBOLO * simbolo = NULL;
	if(table->local == NULL)/*Solo hay ambito global*/
	{
		simbolo = buscar_simbolo(table->global, lexema);
		if(simbolo == NULL)
		{
			return -1;
		}
		else
		{
			if(simbolo->categoria == FUNCION)
				return simbolo->adicional1;
		}
	}
	else/*Hay ambito global y local*/
	{
		simbolo = buscar_simbolo(table->local, lexema);/*Se da prioridad al ambito local*/
		if(simbolo == NULL)
		{
			simbolo = buscar_simbolo(table->global, lexema);
			if(simbolo == NULL)
			{
				return -1;
			}
			else
			{
				if(simbolo->categoria == FUNCION)
					return simbolo->adicional1;
			}
		}
		else
		{
			if(simbolo->categoria == FUNCION)
				return simbolo->adicional1;
		}
	}
	return -1;
}

int obtenerTipo(Table * table, const char *lexema)
{
	INFO_SIMBOLO * simbolo = NULL;
	if(table->local == NULL)/*Solo hay ambito global*/
	{
		simbolo = buscar_simbolo(table->global, lexema);
		if(simbolo == NULL)
		{
			return -1;
		}
		else
		{
			return simbolo->tipo;
		}
	}
	else/*Hay ambito global y local*/
	{
		simbolo = buscar_simbolo(table->local, lexema);/*Se da prioridad al ambito local*/
		if(simbolo == NULL)
		{
			simbolo = buscar_simbolo(table->global, lexema);
			if(simbolo == NULL)
			{
				return -1;
			}
			else
			{
				return simbolo->tipo;
			}
		}
		else
		{
			return simbolo->tipo;
		}
	}
	return -1;
}

int obtenerAdicional1(Table * table, const char *lexema)
{
	INFO_SIMBOLO * simbolo = NULL;
	if(table->local == NULL)/*Solo hay ambito global*/
	{
		simbolo = buscar_simbolo(table->global, lexema);/*Se da prioridad al ambito local*/
		if(simbolo == NULL)
		{
			return -1;
		}
		else
		{
			return simbolo->adicional1;
		}
	}
	else/*Hay ambito global y local*/
	{
		simbolo = buscar_simbolo(table->local, lexema);/*Se da prioridad al ambito local*/
		if(simbolo == NULL)
		{
			return -1;
		}
		else
		{
			return simbolo->adicional1;
		}
	}
	return -1;
}

int obtenerAdicional2(Table * table, const char *lexema)
{
	INFO_SIMBOLO * simbolo = NULL;
	if(table->local == NULL)/*Solo hay ambito global*/
	{
		return -1;
	}
	else/*Hay ambito global y local*/
	{
		simbolo = buscar_simbolo(table->local, lexema);/*Se da prioridad al ambito local*/
		if(simbolo == NULL)
		{
			return -1;
		}
		else
		{
			return simbolo->adicional2;
		}
	}
	return -1;
}

int actualizarParametrosGlobal(Table * table, const char *lexema, int numero_parametros)
{
	INFO_SIMBOLO * simbolo = NULL;
	if(table->local == NULL)/*Solo hay ambito global*/
	{
		simbolo = buscar_simbolo(table->global, lexema);
		if(simbolo == NULL)
		{
			return -1;
		}
		else
		{
			simbolo->adicional1 = numero_parametros;
		}
	}
	else/*Hay ambito global y local*/
	{
		return -1;
	}
	return 0;
}

int actualizarNumParametrosFuncion(Table * table, const char *lexema, int numero_parametros)
{
	INFO_SIMBOLO * simbolo = NULL;
	if(table->local == NULL)/*Solo hay ambito global*/
	{
		return -1;
	}
	else/*Hay ambito global y local*/
	{
		simbolo = buscar_simbolo(table->local, lexema);/*Se da prioridad al ambito local*/
		if(simbolo == NULL)
		{
			return -1;
		}
		else
		{
			simbolo->adicional1 = numero_parametros;
		}
		simbolo = buscar_simbolo(table->global, lexema);
		if(simbolo == NULL)
		{
			return -1;
		}
		else
		{
			simbolo->adicional1 = numero_parametros;
		}
	}
	return 0;
}

/*SE ASUME QUE NO SE VA A INSERTAR UNA FUNCION DENTRO DE OTRA*/
int abrirAmbito(Table * table, const char *lexema, CATEGORIA categ, TIPO tipo, CLASE clase, int adic1, int adic2)
{
	if(table->local != NULL)/*Ya existe un ambito local abierto*/
		return -1;
	table->local = crear_tabla(table->tam);
	if(table->local == NULL)
		return -1;
	if(buscar_simbolo(table->global, lexema) != NULL)/*El simbolo ya existe en la tabla global*/
		return -1;
	insertar_simbolo(table->global, lexema, categ, tipo, clase, adic1, adic2);
	insertar_simbolo(table->local, lexema, categ, tipo, clase, adic1, adic2);
	return 0;
}

int cerrarAmbito(Table * table, const char *lexema)
{
	if(table == NULL)
		return -1;
	if(table->local == NULL)
		return -1;
	liberar_tabla(table->local);
	table->local = NULL;
	return 0;
}