#ifndef TABLE_H
#define TABLE_H
#include "tablaHash.h"
#include "alfa.h"
#include <stdio.h>

typedef struct _Table Table;

Table * crearTabla(int tam);
void eliminarTabla(Table * table);
int insertarElemento(Table * table, const char *lexema, CATEGORIA categ, TIPO tipo, CLASE clase, int adic1, int adic2);
int buscarElemento(Table * table, const char *lexema);
int abrirAmbito(Table * table, const char *lexema, CATEGORIA categ, TIPO tipo, CLASE clase, int adic1, int adic2);
int cerrarAmbito(Table * table, const char *lexema);
int actualizarNumParametrosFuncion(Table * table, const char *lexema, int numero_parametros);
int actualizarParametrosGlobal(Table * table, const char *lexema, int numero_parametros);
int obtenerTipo(Table * table, const char *lexema);
int obtenerCategoria(Table * table, const char *lexema);
int obtenerClase(Table * table, const char *lexema);
int obtenerNumParametros(Table * table, const char *lexema);
int obtenerTipoFuncion(Table * table, const char *lexema);
int buscarEnLocal(Table * table, const char *lexema);
int buscarEnGlobal(Table * table, const char *lexema);
int obtenerAdicional1(Table * table, const char *lexema);
int obtenerAdicional2(Table * table, const char *lexema);
int localAbierto(Table * table);
#endif