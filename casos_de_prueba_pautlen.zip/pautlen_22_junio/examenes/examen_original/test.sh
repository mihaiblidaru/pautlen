#!/bin/bash
make clean;
make;
./alfa ejemplo.c ejemplo.asm
./compile.sh ejemplo.asm ejemplo