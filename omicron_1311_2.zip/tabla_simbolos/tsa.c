#include <hash.h>
#include <simbolo.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tsa.h>

TSA* TSA_crear() {
    TSA* nueva = calloc(1, sizeof(TSA));
    if (nueva == NULL) {
        return NULL;
    } else {
        nueva->ambito = NO_DEFINIDO;
        nueva->global = NULL;
        nueva->local = NULL;
        nueva->id_ambito_local = NULL;
        nueva->id_ambito_global = NULL;
        return nueva;
    }
}
// Como me gusta contradecirte elimino la info de las tablas
// Ademas cambio el prototipo de la funcion
int TSA_eliminar(TSA* ts) {
    if (ts == NULL)
        return ERR;

    if (ts->local != NULL && hash_eliminar(ts->local, InfoSimbolo_eliminar) == ERR) {
        return ERR;
    }

    if (ts->global != NULL && hash_eliminar(ts->global, InfoSimbolo_eliminar) == ERR) {
        return ERR;
    }
    if(ts->id_ambito_global != NULL)
        free(ts->id_ambito_global);

    if(ts->id_ambito_local != NULL)
        free(ts->id_ambito_local);
    free(ts);

    return OK;
}

TSA* TSA_abrirAmbitoGlobal(TSA* ts, const char* id_ambito_global) {
    char nombre_simbolo_info_ambito[100];
    ts->global = hash_crear(DEF_TAM);
    ts->ambito = GLOBAL;
    ts->id_ambito_global = strdup(id_ambito_global);
    sprintf(nombre_simbolo_info_ambito, "%s_%s", id_ambito_global, id_ambito_global);
    InfoSimbolo* info_ambito = InfoSimbolo_crear();

    info_ambito->clave = strdup(nombre_simbolo_info_ambito);
    info_ambito->categoria = CLASE;
    hash_insertar(ts->global, nombre_simbolo_info_ambito, info_ambito);

    return ts;
}

TSA* TSA_abrirAmbitoLocal(TSA* ts, const char* id_ambito,
                        int categoria_ambito,
                        int acceso_metodo,
                        int tipo_metodo,
                        int posicion_metodo_sobre,
                        int tipo_miembro,
                        int numero_parametros) {
    char nombre_simbolo_info_ambito[100];
    ts->local = hash_crear(DEF_TAM);
    ts->ambito = LOCAL;

    // le quito el nombre del ambito global y el underscore
    const char * nombre_sin_prefijo = id_ambito + strlen(ts->id_ambito_global) + 1;


    ts->id_ambito_local = strdup(nombre_sin_prefijo);
    sprintf(nombre_simbolo_info_ambito, "%s_%s", id_ambito, id_ambito);

    InfoSimbolo* info_ambito = InfoSimbolo_crear();

    info_ambito->clave = strdup(id_ambito);
    info_ambito->categoria = categoria_ambito;
    info_ambito->tipo_acceso = acceso_metodo;
    info_ambito->tipo = tipo_metodo;
    info_ambito->posicion_metodo_sobreescribible = posicion_metodo_sobre;
    info_ambito->tipo_miembro = tipo_miembro;
    info_ambito->numero_parametros = numero_parametros;

    hash_insertar(ts->global, id_ambito, info_ambito);
    hash_insertar(ts->local, id_ambito, InfoSimbolo_duplicar(info_ambito));

    return ts;
}

int TSA_cerrarAmbitoLocal(TSA* ts) {
    hash_eliminar(ts->local, InfoSimbolo_eliminar);
    ts->local = NULL;
    ts->ambito = GLOBAL;
    free(ts->id_ambito_local);
    ts->id_ambito_local = NULL;
    return OK;
}



int TSA_insertarSimbolo(TSA* ts,
                        char* clave,
                        int categoria,
                        int tipo,
                        int clase,
                        int direcciones,
                        int numero_parametros,
                        int numero_variables_locales,
                        int posicion_variable_local,
                        int posicion_parametro,
                        int dimension,
                        int tamanio,
                        int filas,
                        int columnas,
                        int capacidad,
                        int numero_atributos_clase,
                        int numero_atributos_instancia,
                        int numero_metodos_sobreescribibles,
                        int numero_metodos_no_sobreescribibles,
                        int tipo_acceso,
                        int tipo_miembro,
                        int posicion_atributo_instancia,
                        int posicion_metodo_sobreescribible,
                        int num_acumulado_atributos_instancia,
                        int num_acumulado_metodos_sobreescritura,
                        int* tipo_args) {
    if (!ts)
        return ERR;
    InfoSimbolo* simbolo = InfoSimbolo_crear();

    simbolo->clave = strdup(clave);
    simbolo->categoria = categoria;
    simbolo->tipo = tipo;
    simbolo->clase = clase;
    simbolo->direcciones = direcciones;
    simbolo->numero_parametros = numero_parametros;
    simbolo->numero_variables_locales = numero_variables_locales;
    simbolo->posicion_variable_local = posicion_variable_local;
    simbolo->posicion_parametro = posicion_parametro;
    simbolo->dimension = dimension;
    simbolo->tamanio = tamanio;
    simbolo->filas = filas;
    simbolo->columnas = columnas;
    simbolo->capacidad = capacidad;
    simbolo->numero_atributos_clase = numero_atributos_clase;
    simbolo->numero_atributos_instancia = numero_atributos_instancia;
    simbolo->numero_metodos_sobreescribibles = numero_metodos_sobreescribibles;
    simbolo->numero_metodos_no_sobreescribibles = numero_metodos_no_sobreescribibles;
    simbolo->tipo_acceso = tipo_acceso;
    simbolo->tipo_miembro = tipo_miembro;
    simbolo->posicion_atributo_instancia = posicion_atributo_instancia;
    simbolo->posicion_metodo_sobreescribible = posicion_metodo_sobreescribible;
    simbolo->num_acumulado_atributos_instancia = num_acumulado_atributos_instancia;
    simbolo->num_acumulado_metodos_sobreescritura = num_acumulado_metodos_sobreescritura;
    simbolo->tipo_args = tipo_args;

    if (ts->ambito == GLOBAL) {
        if (hash_contiene(ts->global, simbolo->clave) == true) {
            return OK;
        } else {
            if (hash_insertar(ts->global, simbolo->clave, simbolo) == ERR) {
                return ERR;
            }
            return OK;
        }
        // AMBITO LOCAL
    } else {
        if (simbolo->categoria == FUNCION) {
            printf("No se puede insertar Funcion en la tabla local");
        } else if (hash_contiene(ts->local, simbolo->clave) == true) {
            return OK;
        } else {
            if (hash_insertar(ts->local, simbolo->clave, simbolo) == ERR) {
                return ERR;
            }
            return OK;
        }
    }
    return ERR;
}

int abrirAmbitoPpalMain(TSA* t) {
    if (TSA_abrirAmbitoGlobal(t, "main") != NULL) {
        return OK;
    }
    return ERR;
}

// EN FUNCION abrirAmbitoMain habra q incluir los parametros que tiene que recibir abrirAmbitoLocal
int abrirAmbitoMain(TSA* t,
                    char* id_ambito,
                    int categoria_ambito,
                    int acceso_metodo,
                    int tipo_metodo,
                    int posicion_metodo_sobre,
                    int tipo_miembro,
                    int numero_parametros
                    ) {
    if (TSA_abrirAmbitoLocal(t, id_ambito, categoria_ambito, acceso_metodo, tipo_metodo, posicion_metodo_sobre, tipo_miembro, numero_parametros) != NULL) {
        return OK;
    }
    return ERR;
}

int cerrarAmbitoMain(TSA* t) {
    return TSA_cerrarAmbitoLocal(t);
}

int buscarParaDeclararIdTablaSimbolosAmbitos(TSA* t, char* id, InfoSimbolo** e, char* id_ambito) {
    int ret_value = ERR;
    int ambito_encontrado = NO_DEFINIDO;
    InfoSimbolo* elem = NULL;

    if (t->local != NULL) {
        elem = hash_buscar(t->local, id, NULL);
        if (elem) {
            ambito_encontrado = LOCAL;
        }
    }

    if (elem == NULL) {
        elem = hash_buscar(t->global, id, NULL);
        if (elem) {
            ambito_encontrado = GLOBAL;
        }
    }

    if (ambito_encontrado != NO_DEFINIDO) {
        ret_value = OK;
        if (e) {
            *e = elem;
        }

        if (id_ambito) {
            if (ambito_encontrado == LOCAL) {
                strcpy(id_ambito, t->id_ambito_local);
            } else {
                strcpy(id_ambito, t->id_ambito_global);
            }
        }
    }
    return ret_value;
}

// esta copiada la anterior, porque no encuentro la diferencia de lo del prefijo
int buscarTablaSimbolosAmbitosConPrefijos(TSA* t, char* id, InfoSimbolo** e, char* id_ambito) {

    if(t->local != NULL){
        char nombre_con_prefijo[50];
        InfoSimbolo* aux = NULL;
        sprintf(nombre_con_prefijo, "%s_%s", t->id_ambito_local, id);

        aux = hash_buscar(t->local, nombre_con_prefijo, NULL);
        if(aux != NULL){
            strcpy(id_ambito, t->id_ambito_local);
            *e = aux;
            return OK;
        }
    }
    if(t->global != NULL){
        char nombre_con_prefijo[50];
        InfoSimbolo* aux = NULL;
        sprintf(nombre_con_prefijo, "%s_%s", t->id_ambito_global, id);

        aux = hash_buscar(t->global, nombre_con_prefijo, NULL);
        if(aux != NULL){
            strcpy(id_ambito, t->id_ambito_global);
            *e = aux;
            return OK;
        }
        return ERR;
    }
    return ERR;
}

void TSA_imprimir(FILE* out, TSA* ts, char* ambito) {
    if (out && ts) {
        bool imprimir_global = true;
        bool imprimir_local = true;
        if (ambito) {
            imprimir_global = !strcmp(ambito, ts->id_ambito_global);
            imprimir_local = !strcmp(ambito, ts->id_ambito_local);
        }

        if (imprimir_local) {
            if (ts->local != NULL) {
                Lista* elementos;
                Lista* posiciones;
                hash_as_list(ts->local, &elementos, &posiciones);
                fprintf(out, "\n=================== %s =================\n", ts->id_ambito_local);

                printf("Elementos encontrados en ambito %s: %d\n\n", ts->id_ambito_local, lista_length(elementos));
                for (int i = 0; i < lista_length(elementos); i++) {
                    InfoSimbolo* elem = lista_get(elementos, i);
                    int* pos = lista_get(posiciones, i);
                    fprintf(out, "\n**************** Posicion %d ******************\n", *pos);
                    InfoSimbolo_imprimir(out, elem, 0);
                }
                lista_free(elementos, NULL);
                lista_free(posiciones, free);
                fprintf(out, "\n");
            }
        }

        if (imprimir_global) {
            if (ts->global == NULL) {
                fprintf(out, "Ambito global no inicializado, no se puede imprimir\n");
            } else {
                Lista* elementos;
                Lista* posiciones;
                hash_as_list(ts->global, &elementos, &posiciones);
                fprintf(out, "\n=================== %s =================\n", ts->id_ambito_global);

                printf("Elementos encontrados en ambito %s: %d\n\n", ts->id_ambito_global, lista_length(elementos));
                for (int i = 0; i < lista_length(elementos); i++) {
                    InfoSimbolo* elem = lista_get(elementos, i);
                    int* pos = lista_get(posiciones, i);
                    fprintf(out, "\n**************** Posicion %d ******************\n", *pos);
                    InfoSimbolo_imprimir(out, elem, 1);
                }
                lista_free(elementos, NULL);
                lista_free(posiciones, free);
                fprintf(out, "\n");
            }
        }
    }
}
