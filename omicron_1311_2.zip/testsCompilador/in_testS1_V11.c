// Programa que eleva un numero al cuadrado

main {
  int x;
  int suma;

  function int fun(int p1){
    int a;
    boolean b;
    a = 12;
    printf a;
    
    return a;
  }

  function none fun2(int p1){
    int a;
    boolean b;
    a = 12;
    printf a;
    
    return none;
  }

  function none vacia(int p1){
    printf x;
    return none;
  }
  suma = 0;
  x = 0;
  while((x <= 10)){
    suma = suma + x;
    x = x + 1;
  }
  
  printf suma; //55
  vacia(13); //11
  fun2(12312312); //12

}
