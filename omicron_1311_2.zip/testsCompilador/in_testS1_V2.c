main {
  int x,y,z,a,b,c;
  int q;
  boolean t,f;

  scanf t;
  printf t;
  scanf f;

  x = 1;
  y = 2;
  z = 10;
  a = x + y;
  b = 4 * y;
  c = a + b;


  printf x;
  printf y;
  printf z;
  printf a;
  printf b;
  printf c;
//
  x = x + y + z + a * b * c;
  printf x;
//
  q = - 3;
  printf q;
  q = - z;
  printf q;
  q = -(-3);
  printf q;
  q = -(-z);
  printf q;
  q = 1 - 2;
  printf q;
  t = t && f;
  printf t;
  t = t || f;
  printf t;
  t = !false;
  printf t;


}
