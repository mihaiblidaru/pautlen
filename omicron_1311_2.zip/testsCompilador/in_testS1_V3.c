main {
  boolean t,f;
  int x, y, r, o, u;

  x = 30;
  y = 0;
  o = 1;
  u = 2;
  r = o + o;

  while((y<=3)){
    printf y;
    y = y + 1;
    if ((y==2)){
      printf y + 10;
    }
    else{
      printf 2;
    }
  }

}
