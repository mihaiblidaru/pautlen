main
{

    int x, y;

	scanf x; //leemos 1
    scanf y; //leemos 2

	printf x+y; // 3

	printf x-y; // -1

	printf x*y; // 2

	printf x/y; // 0

	printf -x;  // -1
}




