/***********************************************************
* hash.c
*
* GRUPO 2:
* 
* CALVENTE RODRIGUEZ, Andres
* DOMINGUEZ GIGANTE, Sergio
* FERNANDEZ TORRES, Lucia
* AYALA VALENCIA, Alberto
* BLIDARU , Mihai 
*
************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "hash.h"
#include <omicron.h>
/**************** FUNCIONES ****************/
NodoHash* crearNodoHash(const char *clave, void *info);
int funcionHash(const char *clave);
int mod(int a,int b);


/**
 * Modulo matematico
 */
int mod(int a,int b){
	return ((a % b) + b) % b;
}


//Recibe el identificador de un nodo y devuelve su indice para la tabla hash.
//Funcion auxiliar, se llama dentro de la funcion insertarNodoHash.
int funcionHash(const char *clave){
	int hash = 5381;
    int c;
	while ((c = *clave++))
        hash = ((hash << 5) + hash) + c; /* hash * 33 + c */

    return hash;
}


//Recibe un tamaño y crea una tabla de dicha longitud.
TablaHash* hash_crear(int tam){
	TablaHash* nueva = calloc(1,sizeof(TablaHash));
	if(nueva == NULL){
		return NULL;
	}else{
		nueva->tam = tam;
		nueva->nodo = calloc(tam, sizeof(NodoHash*));
		if(nueva->nodo == NULL){
			free(nueva);
			return NULL;
		}
		
		return nueva;
	}
}


//Elimina la tabla Hash.
//Devuelve OK en caso de que se borre correctamente y ERR en caso de que no.
int hash_eliminar(TablaHash *tabla, void(*free_data_funct)(void*)){
	int i;
	NodoHash *aux, *aux2;
	if(tabla == NULL)
		return ERR;

	for(i = 0; i < tabla->tam; i++){
		aux = tabla->nodo[i];
		while(aux != NULL){
			aux2 = aux;
			aux = aux->siguiente;
			free(aux2->clave);
			if(free_data_funct != NULL)
				free_data_funct(aux2->info);
				
			free(aux2);
		}
	}

	free(tabla->nodo);
	free(tabla);
	
	return OK;
}


//Recibe la clave y la informacion, y devuelve un nuevo NodoHash. Reservara memoria y rellenara la estructura de NodoHash.
//Funcion auxiliar, se llama dentro de la funcion insertarNodoHash.
NodoHash* crearNodoHash(const char *clave, void *info){
	NodoHash *nuevo = calloc(1, sizeof(NodoHash));
	if(nuevo == NULL){
		return NULL;
	}else{
		nuevo->clave = strdup(clave);
		nuevo->info = info;
		return nuevo;
	}
}


//Inserta en la tabla hash un nodo en un indice calculado por funcionHash.
//Utilizara la funcionHash para saber donde insertar el nuevo elemento y debera crear dentro el nuevo nodo (crearNodoHash).
//Devuelve OK en caso de que se inserte y ERR en caso de que no.
int hash_insertar(TablaHash *tabla, const char *clave, void *info){
	int modulo;
	NodoHash *aux2 = NULL;
	if(tabla == NULL){
		return ERR;
	}

	modulo = mod(funcionHash(clave), tabla->tam);
	aux2 = crearNodoHash(clave, info);	
	if(aux2 == NULL){
		return ERR;
	}
	if(tabla->nodo[modulo] == NULL){
		tabla->nodo[modulo] = aux2;
	}else{
		aux2->siguiente = tabla->nodo[modulo];
		tabla->nodo[modulo] = aux2;
	}
	tabla->length++;
	return OK;
}


//Busca en la tabla hash el nodo identificado por su clave y lo devuelve. NULL en caso contrario.
void* hash_buscar(TablaHash *tabla, const char *clave, int* posicion){
	int modulo;
	NodoHash * aux;
	modulo = mod(funcionHash(clave), tabla->tam);
	aux = tabla->nodo[modulo];
	while(aux != NULL){
		if(strcmp(aux->clave,clave) == 0){
			return aux->info;
		}else{
			aux = aux->siguiente;
		}
	}
	
	if(posicion){
		*posicion = modulo;
	}
	return NULL;
}

/** Devuelve si la tabla hash contiene una clave o no*/
bool hash_contiene(TablaHash* tabla, const char *clave){
	if(tabla != NULL && clave != NULL)
		return hash_buscar(tabla, clave, NULL) != NULL;
	return false;
}

int hash_as_list(TablaHash* tabla, Lista** elementos, Lista** posiciones){
	if(tabla){
		*elementos = lista_crear();
		if(posiciones != NULL){
			*posiciones = lista_crear();
		}
		
		for(int i = 0; i < tabla->tam; i++){
			if(tabla->nodo[i]){
				NodoHash *aux = tabla->nodo[i];
				while(aux != NULL){
					lista_addlast(*elementos, aux->info);
					if(posiciones){
						int* pos = calloc(1, sizeof(int));
						*pos = i;
						lista_addlast(*posiciones, pos);
					}
					aux = aux->siguiente;
				}
			}
		}
		return OK;
	}
	return ERR;
}